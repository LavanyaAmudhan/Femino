<?php
require 'master/PHPMailerAutoload.php'; 

            $name=$_POST['name'];
            $mail=$_POST['mail'];            
            $mailto = $mail;
            $mailSub = "This also you can get it from the form page...";
            $mailMsg = $_POST['message'];
            $mail = new PHPMailer();
            $mail ->IsSmtp();
            $mail ->SMTPDebug = 0;
            $mail ->SMTPAuth = true;
            $mail ->SMTPSecure = 'ssl';
            $mail ->Host = "smtp.gmail.com";
            $mail ->Port = 465; // or 587
            $mail ->IsHTML(true);
            $mail ->Username = "laviammu19@gmail.com";

            $mail ->Password = "Lavanya1999";
            $mail ->SetFrom("laviammu19@gmail.com");
            $mail ->Subject = $mailSub;
            $mail ->Body = $mailMsg;
            $mail ->AddAddress($mailto);

            if($mail->Send())
             {
                 echo "<script>";
                 echo "alert('Mail Sent successfully....');";
                 echo "window.location.href='mail.html';</script>";
             }
            else
             {
                  echo "<script>";
                 echo "alert('Mail not Sent successfully....');";
                 echo "window.location.href='mail.html';</script>";              
             }    

?>


   

