<?php
session_start();
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con, 'fbeauty');
$Name = $_POST['name'];
$Password = $_POST['psw'];
$Rpass = $_POST['cpsw'];
$Mail = $_POST['mail'];
$Phn = $_POST['phn'];
$Aphn= $_POST['aphn'];
$s = "select * from register where name = '$Name'";
$result = mysqli_query($con, $s);
$num = mysqli_num_rows($result);
if($num == 1){
 header('location:sign.html');
}
else{
$b= "insert into register(name , psw , cpsw , mail , phn , aphn ) values ('$Name' , '$Password' , '$Rpass' , '$Mail' , '$Phn' , '$Aphn'  )";
 mysqli_query($con, $b);
 header('location:index.html');
}
?>