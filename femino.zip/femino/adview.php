<!DOCTYPE html>
<html lang="en">
<head>
  <title>Customer database</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <style>
	  body{
 color:white;
 font-size: 20px;
 background:url("mm1.jpg");
 background-repeat:no-repeat;
 background-size:100%;
}
</style>
</head>
<body>
<div class="container">
<center><h1>CUSTOMER DATABASE</h1></center>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Name</th>
         <th>Date</th>
		 <th>Beauticians</th>
		 <th>Mehandhi</th>
		 <th>Makeup</th>
		 <th>Jewelset</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <?php
        $servername ="localhost";
  //create connection
  $con = new mysqli($servername,"root","","fbeauty");
  if($con->connect_error)
  {
    die("connection failed:".$con->connect_error);
  }
  $result = mysqli_query($con,"SELECT * FROM book");
  while($row = mysqli_fetch_array($result)){
      echo "<tr>";
echo "<td>" . $row['Name'] . "</td>";
echo "<td>" . $row['Date'] . "</td>";
echo "<td>" . $row['Beauticians'] . "</td>";
echo "<td>" . $row['Mehandhi'] . "</td>";
echo "<td>" . $row['Makeup'] . "</td>";
echo "<td>" . $row['Jewelset'] . "</td>";
echo "</tr>";
      }?>
    </tbody>
  </table>
  <a href="mail.html" ><button type=submit >Send mail </button></a>
</div>
</body>
</html>