<?php
 session_start();
$con = mysqli_connect('localhost','root','','fbeauty');
  $Name = $_POST['uname'];
  $Date = $_POST['bday'];
  $Beauticians = $_POST['gender'];
  $Mehandhi = $_POST['mehandhi'];
$Makeup = $_POST['makeup'];
$Jewelset = $_POST['jewelset'];
  	$query = mysqli_query($con,"INSERT INTO book(Name,Date,Beauticians,Mehandhi,Makeup,Jewelset) VALUES ('$Name',  '$Date', '$Beauticians', '$Mehandhi', '$Makeup', '$Jewelset')");
	if($query)
	{
		
  	header('location: online.html');
	}
	else{
		echo"no";
	}
?>
		