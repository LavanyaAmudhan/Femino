<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>FEMINO</title>
  <link rel="stylesheet" type="text/css" href="style.css">
<style>
	  body{
 background:url("bride3.jpg");
 background-repeat:no-repeat;
 background-size:100%;
}
</style>
</head>
<body>
<h1> <p>WELCOME TO FEMINO BEAUTY</p><br>
  <a href="admin.php"> ADMIN PAGE </a> </h1>
  <div class="header">
  	<h2>Customer Login</h2>
  </div>
	 
  <form method="post" action="login.php">
  	<?php include('errors.php'); ?>
  	<div class="input-group">
  		<label>Username</label>
  		<input type="text" name="username" >
  	</div>
  	<div class="input-group">
  		<label>Password</label>
  		<input type="password" name="password">
  	</div>
  	<div class="input-group">
  		<button type="submit" class="btn" name="login_user">Login</button>
  	</div>
  	<p>
  		Not yet a member? <a href="register.php">Sign up</a>
  	</p>
  </form>
</body>
</html>