<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Femino</title>
<meta name="description" content="">
<meta name="author" content="">
<!-- Favicons
    ================================================== -->
<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
<link rel="apple-touch-icon" href="img/apple-touch-icon.png">
<link rel="apple-touch-icon" sizes="72x72" href="img/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="114x114" href="img/apple-touch-icon-114x114.png">

<!-- Bootstrap -->
<link rel="stylesheet" type="text/css"  href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.css">

<!-- Slider
    ================================================== -->
<link href="css/owl.carousel.css" rel="stylesheet" media="screen">
<link href="css/owl.theme.css" rel="stylesheet" media="screen">

<!-- Stylesheet
    ================================================== -->
<link rel="stylesheet" type="text/css"  href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/nivo-lightbox/nivo-lightbox.css">
<link rel="stylesheet" type="text/css" href="css/nivo-lightbox/default.css">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,700,800,600,300" rel="stylesheet" type="text/css">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
 
<style>
p{
color:white;
}
</style>
</head>
<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
<!-- Navigation

    ==========================================-->

<nav id="menu" class="navbar navbar-default navbar-fixed-top">

  <div class="container"> 
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
	
 <?php  if (isset($_SESSION['username'])) : ?>
    	<p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>
    	<p> <a href="index.php?logout='1'" style="color: red;">logout</a> </p>
    <?php endif ?>
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <a class="navbar-brand page-scroll" href="#page-top">HOME</a> </div>
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="booking.html" class="page-scroll">Book Order </a></li>
        <li><a href="#about" class="page-scroll">About</a></li>
        <li><a href="#portfolio" class="page-scroll">Gallery</a></li>
      </ul>
    </div>
    <!-- /.navbar-collapse --> 
  </div>
  <!-- /.container-fluid --> 
</nav>
<!-- Header -->
<header id="header">
  <div class="intro">
    <div class="overlay">
      <div class="container">
        <div class="row">
          <div class="intro-text"> <span>Welcome to</span>
            <h1>FEMINO BEAUTY</h1>
            <p> Romantic poet John Keats says, �A thing of beauty is joy forever�. <br>
But what gives your beauty an eternal glow is a range of cosmetics products.</p>
              </div>
        </div>
      </div>
    </div>
  </div>
</header>
<!-- About Section -->
<div id="about">
  <div class="container">
    <div class="section-title text-center center">
      <h2>About Us</h2>
      <hr>
    </div>
    <div class="row">
      <div class="col-xs-12 col-md-6"> <img src=" img/iii.jpg" class="img-responsive" alt=""> </div>
      <div class="col-xs-12 col-md-6">
        <div class="about-text">
           <p><font color="dark red"><b><Femino Beauty welcomes you to the beautiful world of beauty products online.<br> 
Before you start grooming yourself from head to toe, take a look at our online <br>
beauty care products store brimming with makeup & cosmetic products.<br>
The store includes every product you need to enhance your looks & personality. <br>
   
The amazing store of beauty products at online.The store is categorised into <br>
skin care products, body care products, bath & spa products.It is packed with <br>
shaving products, lipsticks & nail polish, eye care, face care, hair care and more.<br>
Don't let the Summer have an impact on your skin.With the makeup and cosmetics online,<br>
the shopping has been made easier for you than ever.Keep yourself ever ready for any occassion<br>
we provide function booking like qualified mehandhi,loyal looking jewel set,royal looking makeup.</b></font></p>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Portfolio Section -->
<div id="portfolio">
  <div class="container">
    <div class="section-title text-center center">
      <h2>Gallery</h2>
      <hr>
      <p> Femino Beauty</p>
    </div>
    <div class="categories">
      <ul class="cat">
        <li>
          <ol class="type">
             <li><a href="#" data-filter="*" class="active">All</a></li>
            <li><a href="#" data-filter=".lorem">Make up</a></li>
            <li><a href="#" data-filter=".dolor">Mehandhi</a></li>
            <li><a href="#" data-filter=".adipiscing">Jewel set</a></li>
          </ol>
        </li>
      </ul>
      <div class="clearfix"></div>
    </div>
    <div class="row">
      <div class="portfolio-items">
        <div class="col-sm-6 col-md-3 col-lg-3 lorem">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/bride1.jpg" title="Reception look" data-lightbox-gallery="gallery1">
              <div class="hover-text">
                <h4>Reception look</h4>
              </div>
              <img src="img/portfolio/bride1.jpg" class="img-responsive" alt="Reception look"> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-3 adipiscing">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/j2.jpg" title="SemiBridal set" data-lightbox-gallery="gallery1">
              <div class="hover-text">
                <h4>SemiBridal set</h4>
              </div>
              <img src="img/portfolio/j2.jpg" class="img-responsive" alt="SemiBridal set"> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-3 lorem">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/p1jpg.jpg" title="Party look" data-lightbox-gallery="gallery1">
              <div class="hover-text">
                <h4>Party look</h4>
              </div>
              <img src="img/portfolio/p1jpg.jpg" class="img-responsive" alt="Party look"> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-3 lorem">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/mm1.jpg" title="Mugurtham look" data-lightbox-gallery="gallery1">
              <div class="hover-text">
                <h4>Mugurtham look</h4>
              </div>
              <img src="img/portfolio/mm1.jpg" class="img-responsive" alt="Mugurtham look"> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-3 adipiscing">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/j5.jpg" title="Daimond set" data-lightbox-gallery="gallery1">
              <div class="hover-text">
                <h4>Daimond set</h4>
              </div>
              <img src="img/portfolio/j5.jpg" class="img-responsive" alt="Daimond set"> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-3 dolor">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/m1.jpg" title="Pakistani" data-lightbox-gallery="gallery1">
              <div class="hover-text">
                <h4>Pakistani</h4>
              </div>
              <img src="img/portfolio/m1.jpg" class="img-responsive" alt="Pakistani"> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-3 dolor">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/m5.jpg" title="Indian" data-lightbox-gallery="gallery1">
              <div class="hover-text">
                <h4>Indian</h4>
              </div>
              <img src="img/portfolio/m5.jpg" class="img-responsive" alt="Indian"> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-3 lorem">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/p6.jpg" title="Party look" data-lightbox-gallery="gallery1">
              <div class="hover-text">
                <h4>Party look</h4>
              </div>
              <img src="img/portfolio/p6.jpg" class="img-responsive" alt="Party look"> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-3 adipiscing">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/j7.jpg" title="Temple set" data-lightbox-gallery="gallery1">
              <div class="hover-text">
                <h4>Temple set</h4>
</div>           
<img src="img/portfolio/j7.jpg" class="img-responsive" alt="Temple set"> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-3 dolor">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/m6.jpg" title="Bangle" data-lightbox-gallery="gallery1">
              <div class="hover-text">
                <h4>Bangle</h4>
              </div>
              <img src="img/portfolio/m6.jpg" class="img-responsive" alt="Bangle"> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-3 dolor">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/m3.jpg" title="Bridal" data-lightbox-gallery="gallery1">
              <div class="hover-text">
                <h4>Bridal</h4>
              </div>
              <img src="img/portfolio/m3.jpg" class="img-responsive" alt="Bridal"> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-3 lorem">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/bride3.jpg" title="Reception look" data-lightbox-gallery="gallery1">
              <div class="hover-text">
                <h4>Reception look</h4>
              </div>
              <img src="img/portfolio/bride3.jpg" class="img-responsive" alt="Reception look"> </a> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
      </form>
<script type="text/javascript" src="js/jquery.1.11.1.js"></script> 
<script type="text/javascript" src="js/bootstrap.js"></script> 
<script type="text/javascript" src="js/SmoothScroll.js"></script> 
<script type="text/javascript" src="js/jquery.counterup.js"></script> 
<script type="text/javascript" src="js/waypoints.js"></script> 
<script type="text/javascript" src="js/nivo-lightbox.js"></script> 
<script type="text/javascript" src="js/jquery.isotope.js"></script> 
<script type="text/javascript" src="js/jqBootstrapValidation.js"></script> 
<script type="text/javascript" src="js/contact_me.js"></script> 
<script type="text/javascript" src="js/owl.carousel.js"></script> 
<script type="text/javascript" src="js/main.js"></script>
</body>
</html>