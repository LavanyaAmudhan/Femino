<?php
require 'master/PHPMailerAutoload.php'; 

            $name=$_POST['msg'];
            $mail=$_POST['email'];
            $mailto = $mail;
            $mailSub = "Registerd Successfully";
            $mailMsg = "You have been successfully registered into Domain-Info" ;
            $mail = new PHPMailer();
            $mail ->IsSmtp();
            $mail ->SMTPDebug = 0;
            $mail ->SMTPAuth = true;
            $mail ->SMTPSecure = 'ssl';
            $mail ->Host = "smtp.gmail.com";
            $mail ->Port = 465; // or 587
            $mail ->IsHTML(true);
            $mail ->Username = "laviammu19@gmail.com";
            $mail ->Password = "Lavanya1999";
            $mail ->SetFrom("laviammu19@gmail.com");
            $mail ->Subject = $mailSub;
            $mail ->Body = $mailMsg;
            $mail ->AddAddress($mailto);

            if($mail->Send())
             {
                 echo "<script>";
                 echo "alert('Mail Sent successfully....');";
                 echo "window.location.href='adview.php';</script>";
             }
            else
             {
                  echo "<script>";
                 echo "alert('Mail not Sent successfully....');";
                 echo "window.location.href='adview.php';</script>";              
             }
                    
         

     
    

?>


   

