<?php
$con = mysqli_connect("localhost","root","","fbeauty");
session_start();
$Name=($_POST['uname']);
$Password=($_POST['psw']);
$result=mysqli_query($conn,"select *from register where Name='$fname' and Password='$fpsw'");
while(mysql_fetch_array($result,MYSQLI_ASSOC)){
	header("location:booking.html");
}
if(!mysql_fetch_array($result,MYSQLI_ASSOC)){
	echo"Invalid username and password";
}
?>